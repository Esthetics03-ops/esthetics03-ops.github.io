# Changelog

## [v1.0] - 2025-09-20
### Added
- Modernized blog homepage with post summaries
- Three stripped-down posts with clean layout
- Optimized and lazy-loaded inline images
- Minified HTML & CSS for performance
- MIT License
- GitHub-ready repo structure
- Initialized Git history with `main` branch
- Release tag `v1.0`
