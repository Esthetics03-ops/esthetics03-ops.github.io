# esthetics-blog

Modernized and optimized blog project.  
Release: **v1.0** (2025-09-20)

![Homepage Preview](images/preview.png)

## Features
- Modern homepage with post summaries
- Three stripped-down posts with clean layout
- Optimized, lazy-loaded images
- Minified HTML & CSS
- MIT License
- GitHub-ready with initialized Git history + tag `v1.0`
- CHANGELOG included

## How to use
Unzip, rename the folder to `esthetics-blog`, then:

```bash
cd esthetics-blog
# if the .git metadata was not preserved, initialize and push:
git remote add origin https://github.com/your-username/esthetics-blog.git
git push -u origin main
```
